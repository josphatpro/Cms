/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cms;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;

/**
 *
 * @author Prototype
 */
public class ConnectionUtil {
 Connection conn = null;
  private static Statement stmt = null;
  

public static Connection connectdb()
{
    //sqlite db connection
    //String driver="org.sqlite.JDBC";
    //String url ="jdbc:sqlite:schoolsys.db";
            
    try
    {
    //Class.forName(driver);
    //System.out.println("Driver Loaded");
    //Connection connection = DriverManager.getConnection(url);
    //System.out.println("Database connected");
    //connection.setAutoCommit(true);
      
     //uncomment for mysql database connection
     Class.forName("com.mysql.jdbc.Driver");
     System.out.println("Driver Loaded");
     Connection connection = DriverManager.getConnection("jdbc:mysql://localhost/schoolsys","prototype","6889");
     System.out.println("Database connected");
     connection.setAutoCommit(true);
     
     return connection;

    }
    catch(Exception e)
    {
        JOptionPane.showMessageDialog(null, e);
        return null;
    }
    
  }
   public void setupUserInfoTable() {
        String TABLE_NAME = "user_info";
        try {
            stmt = conn.createStatement();

            DatabaseMetaData dbm = conn.getMetaData();
            ResultSet tables = dbm.getTables(null, null, TABLE_NAME.toUpperCase(), null);

            if (tables.next()) {
                System.out.println("Table " + TABLE_NAME + "already exists. Ready for go!");
            } else {
                stmt.execute("CREATE TABLE " + TABLE_NAME + "("
                        + "	id varchar(200) primary key,\n"
                        + "	title varchar(200),\n"
                        + "	author varchar(200),\n"
                        + "	publisher varchar(100),\n"
                        + "	isAvail boolean default true"
                        + " )");
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage() + " --- setupDatabase");
        } finally {
        }
    }
}
