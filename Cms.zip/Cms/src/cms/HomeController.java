/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cms;

import java.awt.Desktop;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.function.Predicate;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Pane;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.ButtonType;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Prototype
 */
public class HomeController implements Initializable {
    
    Connection connection =ConnectionUtil.connectdb();
    ObservableList<Contact> data=FXCollections.observableArrayList();
    FilteredList<Contact> filteredData=new FilteredList<>(data,e->true);
    PreparedStatement preparedStatement = null;
    ResultSet rs = null;
    private final Desktop desktop = Desktop.getDesktop();
         
    @FXML
    private TableView<Contact> table;
    
    @FXML
    private TableColumn<?, ?> idCol;
    @FXML
    private TableColumn<?, ?> fnameCol;
    
    @FXML
    private TableColumn<?, ?> lnameCol;
    
    @FXML
    private TableColumn<?, ?> phoneCol;
    
    @FXML
    private TableColumn<?, ?> emailCol;
    
    @FXML
    private TableColumn<?, ?> streetCol;
    
    @FXML
    private TableColumn<?, ?> cityCol;
    
    @FXML
    private TableColumn<?, ?> countryCol;
     
     @FXML
     private TextField fnameBox;
     @FXML
     private TextField lnameBox;
     @FXML
     private TextField phoneBox;
     @FXML
     private TextField emailBox;
     @FXML
     private TextField streetBox;
     @FXML
     private TextField cityBox;
     @FXML
     private TextField countryBox;
     @FXML
     private TextField idBox;
     
     @FXML
     private TextField searchBox;
          
     @FXML
     private Button clearBtn;
          
     @FXML
     private Button printBtn;
               
     @FXML
     private Button exelBtn;
     @FXML
     private Pane display;
      
    @Override
    public void initialize(URL arg0, ResourceBundle arg1) {
        
      String value="-fx-text-fill:white;";
      idCol.setCellValueFactory(new PropertyValueFactory<>("id"));
      idCol.setStyle(value);
      fnameCol.setCellValueFactory(new PropertyValueFactory<>("fname"));
      fnameCol.setStyle(value);
      lnameCol.setCellValueFactory(new PropertyValueFactory<>("lname"));
      lnameCol.setStyle(value);
      phoneCol.setCellValueFactory(new PropertyValueFactory<>("phone"));
      phoneCol.setStyle(value);
      emailCol.setCellValueFactory(new PropertyValueFactory<>("email"));
      emailCol.setStyle(value);
      streetCol.setCellValueFactory(new PropertyValueFactory<>("street"));
      streetCol.setStyle(value);
      cityCol.setCellValueFactory(new PropertyValueFactory<>("city"));
      cityCol.setStyle(value);
      countryCol.setCellValueFactory(new PropertyValueFactory<>("country"));
      countryCol.setStyle(value);
      idBox.setEditable(false);
      
      loadContacts();
      
    }    
        @FXML public void saveContact() throws SQLException{
    

           String query = "INSERT INTO contact_info(fname,lname,phone,email,street,city,country) VALUES(?,?,?,?,?,?,?)";

           preparedStatement = null;


           try
           {
             preparedStatement = connection.prepareStatement(query);
             
             
             preparedStatement.setString(1,fnameBox.getText());
             preparedStatement.setString(2,lnameBox.getText());
             preparedStatement.setInt(3,Integer.parseInt(phoneBox.getText()));
             preparedStatement.setString(4,emailBox.getText());
             preparedStatement.setString(5,streetBox.getText());
             preparedStatement.setString(6,cityBox.getText());
             preparedStatement.setString(7,countryBox.getText());
           }
           catch(SQLException e)
           {
               System.out.println(e);
           }
           finally
           {
               preparedStatement.execute();
               preparedStatement.close();
           }

         data.clear();
         clearFields();
         loadContacts();

    }
        public void clearFields(){
         idBox.clear();
         fnameBox.clear();
         lnameBox.clear();
         phoneBox.clear();
         emailBox.clear();
         streetBox.clear();
         cityBox.clear();
         countryBox.clear(); 
         searchBox.clear();
        }
    @FXML
    public void loadTable(){
      String query = "select * from contact_info";
      try
      {
          preparedStatement = connection.prepareStatement(query);
          rs=preparedStatement.executeQuery();
          while(rs.next())
          {
              data.add(new Contact(
                      rs.getInt("id"),
                      rs.getString("fname"),
                      rs.getString("lname"),
                      rs.getInt("phone"),
                      rs.getString("email"),
                      rs.getString("street"),
                      rs.getString("city"),
                      rs.getString("country")
                     
                        ));
              
          }
          
          preparedStatement.close();
          rs.close();
      }
      catch(Exception e)
      {
          System.err.println(e);
      }
    }
    public void loadContacts()
     {
      String query = "select * from contact_info";
      try
      {
          preparedStatement = connection.prepareStatement(query);
          rs=preparedStatement.executeQuery();
          while(rs.next())
          {
              data.add(new Contact(
                      rs.getInt("id"),
                      rs.getString("fname"),
                      rs.getString("lname"),
                      rs.getInt("phone"),
                      rs.getString("email"),
                      rs.getString("street"),
                      rs.getString("city"),
                      rs.getString("country")
                        ));
              
              table.setItems(data);
          }
          
          preparedStatement.close();
          rs.close();
      }
      catch(Exception e)
      {
          System.err.println(e);
      }
    }
        static int tempId;
    	@FXML
	public void showOnClick()
	{
		try
		{
			Contact contact=(Contact)table.getSelectionModel().getSelectedItem();
			String query="select * from contact_info";
			preparedStatement=connection.prepareStatement(query);
			
                        int id =contact.getId();
                        String c_id= Integer.toString(id);
                        idBox.setText(c_id);
			fnameBox.setText(contact.getFname());
			lnameBox.setText(contact.getLname());
                        int x = contact.getPhone();
                        String myString = Integer.toString(x);
                        phoneBox.setText(myString);
			emailBox.setText(contact.getEmail());
                        streetBox.setText(contact.getStreet());
                        cityBox.setText(contact.getCity());
			countryBox.setText(contact.getCountry());
                        
			preparedStatement.close();
			rs.close();
		}
		catch(SQLException e)
		{
			System.out.println(e);
		}
	}
        @FXML
	public void UpdateContact() 
	{
  
		String query="update contact_info set fname=?, lname=?,phone=?,email=?,street=?,city=?,country=? where id='"+idBox.getText()+"'";

		try
		{
			preparedStatement=connection.prepareStatement(query);
			preparedStatement.setString(1, fnameBox.getText());
			preparedStatement.setString(2, lnameBox.getText());
			preparedStatement.setInt(3, Integer.parseInt(phoneBox.getText()));
                        preparedStatement.setString(4, emailBox.getText());
			preparedStatement.setString(5, streetBox.getText());
			preparedStatement.setString(6, cityBox.getText());
                        preparedStatement.setString(7, countryBox.getText());
			preparedStatement.execute();
			preparedStatement.close();
			Cms.showInformationAlertBox("User '"+fnameBox.getText()+"' Updated Successfully!");	
			data.clear();
                        
                        loadContacts();
		}
		catch(SQLException e)
		{
			System.out.println(e);
		}
	}
       @FXML
	public void deleteContact()
	{
		String name = null;
                Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText(null);
                alert.setContentText("Are you sure to delete?");
                Optional <ButtonType> action = alert.showAndWait();

                if(action.get() == ButtonType.OK){
		try
		{
			Contact contact=(Contact)table.getSelectionModel().getSelectedItem();
			String query="delete from contact_info where id=?";
			preparedStatement=connection.prepareStatement(query);
			preparedStatement.setInt(1, Integer.parseInt(idBox.getText()));;
			name=contact.getFname();
			preparedStatement.executeUpdate();
			
			preparedStatement.close();
			rs.close();
		}
		catch(SQLException e)
		{
			System.out.println(e);
		}
                data.clear();
		loadContacts();
		Cms.showInformationAlertBox("Contact '"+name+"' Deleted Successfully!");
                clearFields();
                }
	}
        @FXML
	public void searchContact()
	{
		searchBox.textProperty().addListener((observableValue,oldValue,newValue)->{
			filteredData.setPredicate((Predicate<? super Contact>)contact->{
				if(newValue==null||newValue.isEmpty()){
					return true;
				}
				String lowerCaseFilter=newValue.toLowerCase();
				if(contact.getFname().toLowerCase().contains(lowerCaseFilter)){
					return true;
				}
				else if(contact.getLname().toLowerCase().contains(lowerCaseFilter)){
					return true;
				}
				return false;
			});
		});
		SortedList<Contact> sortedData=new SortedList<>(filteredData);
		sortedData.comparatorProperty().bind(table.comparatorProperty());
		table.setItems(sortedData);
	}
        @FXML
        public void newSearch(){
            FilteredList<Contact> filteredData = new FilteredList<>(data,e -> true);
          
              searchBox.textProperty().addListener((observableValue,oldValue,newValue)->{
                  filteredData.setPredicate((Predicate<? super Contact>)contact->{
                    if(newValue==null||newValue.isEmpty()){
                            return true;
                    }  
                    String lowerCaseFilter=newValue.toLowerCase();

                    if(contact.getFname().toLowerCase().contains(lowerCaseFilter)){
                            return true;
                    }
                    else if(contact.getLname().toLowerCase().contains(lowerCaseFilter)){
                            return true;
                    }
                    return false;  
                      
                  
               });
            });
       
        }
        @FXML
        public void printContacts(){
            PrintReport viewReport = new PrintReport();
            viewReport.showReport();
        }
        @FXML
        public void exportToCSV(){
          try{
              String query ="select * from contact_info";
              preparedStatement=connection.prepareStatement(query);
              rs=preparedStatement.executeQuery();
          
              XSSFWorkbook wb = new XSSFWorkbook();
              XSSFSheet sheet = wb.createSheet("My Contacts");
              XSSFRow header = sheet.createRow(0);
              header.createCell(0).setCellValue("ID");
              header.createCell(1).setCellValue("FIRST NAME");
              header.createCell(2).setCellValue("LAST NAME");
              header.createCell(3).setCellValue("PHONE");
              header.createCell(4).setCellValue("EMAIL");
              header.createCell(5).setCellValue("STREET");
              header.createCell(6).setCellValue("CITY");
              header.createCell(7).setCellValue("COUNTRY");

              int index = 1;
              while(rs.next()){
                  XSSFRow row = sheet.createRow(index);
                  row.createCell(0).setCellValue(rs.getString("id"));
                  row.createCell(1).setCellValue(rs.getString("fname"));
                  row.createCell(2).setCellValue(rs.getString("lname"));
                  row.createCell(3).setCellValue(rs.getString("phone"));
                  row.createCell(4).setCellValue(rs.getString("email"));
                  row.createCell(5).setCellValue(rs.getString("street"));
                  row.createCell(6).setCellValue(rs.getString("city"));
                  row.createCell(7).setCellValue(rs.getString("country"));
                  index++;
              }
              FileOutputStream fileOut =new FileOutputStream("Mycontacts.xlsx");
              wb.write(fileOut);
              fileOut.close();
              
              Alert alert =new Alert(Alert.AlertType.INFORMATION);
              alert.setTitle("Information Dialog");
              alert.setHeaderText(null);
              alert.setContentText("contacts exported to Excel Sheet successfully");
              alert.showAndWait();
              
              preparedStatement.close();
              rs.close();
              
          } catch (SQLException | FileNotFoundException ex) {
            Logger.getLogger(HomeController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(HomeController.class.getName()).log(Level.SEVERE, null, ex);
        }  
        }
        

    @FXML
    public void signOut(ActionEvent event) throws Exception{
        display = new Pane();
        display = FXMLLoader.load(getClass().getResource("Login.fxml"));
        
        Scene scene = new Scene(display);
        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        stage.hide();
        stage.setScene(scene); 
        stage.show();
    }


}
