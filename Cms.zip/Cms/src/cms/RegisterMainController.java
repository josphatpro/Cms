/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cms;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Prototype
 */
public class RegisterMainController implements Initializable {
    Connection connection =ConnectionUtil.connectdb();
    ObservableList<Contact> data=FXCollections.observableArrayList();
    FilteredList<Contact> filteredData=new FilteredList<>(data,e->true);
    PreparedStatement preparedStatement = null;
    ResultSet rs = null;
    
    @FXML 
    private TextField fnameBox;
    @FXML 
    private TextField lnameBox;
    @FXML 
    private TextField unameBox;
    @FXML 
    private TextField emailBox;
    @FXML 
    private PasswordField passBox;
    @FXML 
    private PasswordField confpassBox;
    
    @FXML
    private Label fnameLabel;
    @FXML
    private Label lnameLabel;
    @FXML 
    private Label unameLabel;
    @FXML
    private Label emailLabel;
    @FXML
    private Label passLabel;
    @FXML
    private Label cpassLabel; 
    @FXML
    private Pane display;
    @FXML
    public void goBack(ActionEvent event) throws IOException{
        display = new Pane();
        display = FXMLLoader.load(getClass().getResource("Login.fxml"));
        
        Scene scene = new Scene(display);
        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        stage.hide();
        stage.setScene(scene); 
        stage.show();
    }
           @FXML public void registerUser() throws SQLException{
    
           if(validateFname() & validateLname()& validateUname()& validateEmail()& validatePassword()& validatePassword2() & comparePassword()){
           String query = "INSERT INTO user_info(f_name,l_name,username,email,pass) VALUES(?,?,?,?,?)";

           preparedStatement = null;


           try
           {
             preparedStatement = connection.prepareStatement(query);
             
             preparedStatement.setString(1,fnameBox.getText());
             preparedStatement.setString(2,lnameBox.getText());
             preparedStatement.setString(3,unameBox.getText());
             preparedStatement.setString(4,emailBox.getText());
             preparedStatement.setString(5,passBox.getText());
         
           }
           catch(SQLException e)
           {
               System.out.println(e);
           }
           finally
           {
               
               preparedStatement.execute();         
               preparedStatement.close();
               Cms.showInformationAlertBox("Your account has been created successfully!");
               fnameBox.clear();
               lnameBox.clear();
               unameBox.clear();
               emailBox.clear();
               passBox.clear();
               confpassBox.clear();
           }

        }
    }
    @FXML
    private boolean validateFname(){
        Pattern p = Pattern.compile("[a-zA-Z]+");
        Matcher m = p.matcher(fnameBox.getText());
        if(m.find() && m.group().equals(fnameBox.getText())){
            fnameLabel.setText("");
            return true;
        }else{
              fnameLabel.setText("Enter a valid First Name");
              fnameLabel.setTextFill(Color.RED);

            return false;
        }
    }
    @FXML
    private boolean validateLname(){
        Pattern p = Pattern.compile("[a-zA-Z]+");
        Matcher m = p.matcher(lnameBox.getText());
        if(m.find() && m.group().equals(lnameBox.getText())){
            lnameLabel.setText("");
            return true;
        }else{
              lnameLabel.setText("Enter a valid Last Name");
              lnameLabel.setTextFill(Color.RED);
              
            return false;
        }
    }
    @FXML
    private boolean validateUname(){
        Pattern p = Pattern.compile("[a-zA-Z]+");
        Matcher m = p.matcher(unameBox.getText());
        if(m.find() && m.group().equals(unameBox.getText())){
            unameLabel.setText("");
            return true;
        }else{
              unameLabel.setText("Enter a valid User Name");
              unameLabel.setTextFill(Color.RED);
              
            return false;
        }
    }
    @FXML
    private boolean validateEmail(){
        Pattern p = Pattern.compile("[a-zA-Z0-9][a-zA-Z0-9._]*@[a-zA-Z0-9]+([.][a-zA-Z]+)+");
        Matcher m = p.matcher(emailBox.getText());
        if(m.find() && m.group().equals(emailBox.getText())){
             emailLabel.setText("");
            return true;
        }else{
              emailLabel.setText("");
              emailLabel.setText("Enter a valid Email Address");
              emailLabel.setTextFill(Color.RED);
            return false;
        }
    }

    @FXML
    private boolean validatePassword(){
        
        Pattern p = Pattern.compile("((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{6,15})");
        Matcher m = p.matcher(passBox.getText());
        if(m.matches()){
             passLabel.setText("");
            return true;
        }else{
              passLabel.setText("Password must contain at least one(Digit, Lowercase, UpperCase and Special Character) and length must be between 6 -15");
              passLabel.setTextFill(Color.RED);

            return false;
        }
    }
        @FXML
    private boolean validatePassword2(){
        
        Pattern p = Pattern.compile("((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{6,15})");
        Matcher m = p.matcher(confpassBox.getText());
        if(m.matches()){
            cpassLabel.setText("");
            return true;
        }else{
              cpassLabel.setText("Password must contain at least one(Digit, Lowercase, UpperCase and Special Character) and length must be between 6 -15");
              cpassLabel.setTextFill(Color.RED);

            return false;
        }
    }
    
    @FXML
    private boolean comparePassword(){
        String pass1=passBox.getText();
        String pass2=confpassBox.getText();
        if(pass1.equals(pass2)){
            cpassLabel.setText("");
            return true;
            
        }else{
            cpassLabel.setText("Password do not match");
            cpassLabel.setTextFill(Color.RED);
 
            return false;
        }
    }
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
