/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cms;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Prototype
 */
public class LoginController implements Initializable {
    private static Statement stmt = null;
    @FXML
    private Pane display;
    @FXML
    private Label label;
    @FXML
    private TextField username;
    @FXML
    private PasswordField password;
    @FXML 
    private Button btn_login;
    Stage dialogStage = new Stage();
    Scene scene;
    
    Connection connection = null;
    PreparedStatement preparedStatement = null;
    ResultSet resultSet = null;
    
        @FXML
    private void login(ActionEvent event) {
    String uname = username.getText();
    String pass = password.getText();
    String sql = "SELECT * FROM user_info WHERE username = ? and pass = ?";

    try{
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, uname);
            preparedStatement.setString(2, pass);
            resultSet = preparedStatement.executeQuery();
            if(!resultSet.next()){
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Error");
            alert.setHeaderText("Login Error");
            alert.setContentText("Username/Password incorrect");
            alert.showAndWait();
    }else{
           Node source = (Node) event.getSource();
            dialogStage = (Stage) source.getScene().getWindow();
            dialogStage.close();
            Stage stage = new Stage();
            Parent root = FXMLLoader.load(getClass().getResource("Home.fxml"));

            Scene scene = new Scene(root);

            stage.setScene(scene);
            stage.setTitle("ContactSys");
            stage.show();
    }

    }catch(Exception e){
     e.printStackTrace();
    }
    }

    @FXML
    public void register(ActionEvent event) throws IOException{
        display = new Pane();
        display = FXMLLoader.load(getClass().getResource("RegisterMain.fxml"));
        
        Scene scene = new Scene(display);
        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        stage.hide();
        stage.setScene(scene); 
        stage.show();
    }
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        connection = ConnectionUtil.connectdb();
        setupUserInfoTable();
        setupContactInfoTable();
    }    
       public void setupUserInfoTable() {
        String TABLE_NAME = "user_info";
        try {
            stmt = connection.createStatement();

            DatabaseMetaData dbm = connection.getMetaData();
            ResultSet tables = dbm.getTables(null, null, TABLE_NAME.toUpperCase(), null);

            if (tables.next()) {
                System.out.println("Table " + TABLE_NAME + " already exists. Ready for go!");
            } else {
                stmt.execute("CREATE TABLE " + TABLE_NAME + "("
                        + "	id int (13) primary key auto_increment,\n"
                        + "	f_name varchar(200),\n"
                        + "	l_name varchar(200),\n"
                        + "	email varchar(100),\n"
                        + "     username varchar(100),\n"
                        + "	pass varchar(100)\n"
                        + " )");
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage() + " --- setupDatabase");
        } finally {
        }
    }
        public void setupContactInfoTable() {
        String TABLE_NAME = "contact_info";
        try {
            stmt = connection.createStatement();

            DatabaseMetaData dbm = connection.getMetaData();
            ResultSet tables = dbm.getTables(null, null, TABLE_NAME.toUpperCase(), null);

            if (tables.next()) {
                System.out.println("Table " + TABLE_NAME + " already exists. Ready for go!");
            } else {
                stmt.execute("CREATE TABLE " + TABLE_NAME + "("
                        + "	id int(13) primary key auto_increment,\n"
                        + "	fname varchar(200),\n"
                        + "	lname varchar(200),\n"
                        + "	phone int(100),\n"
                        + "	email varchar(200),\n"
                        + "	street varchar(200),\n"
                        + "     city varchar(200),\n"
                        + "     country varchar(200)\n"
                        + " )");
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage() + " --- setupDatabase");
        } finally {
        }
    }   
}
